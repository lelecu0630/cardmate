ALTER TABLE `rooms` ADD `visibility` text DEFAULT 'private' NOT NULL;--> statement-breakpoint
ALTER TABLE `rooms` ADD `title` text DEFAULT '' NOT NULL;--> statement-breakpoint
ALTER TABLE `rooms` ADD `host_seen` integer DEFAULT 0 NOT NULL;