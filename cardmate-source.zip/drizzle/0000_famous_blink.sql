CREATE TABLE `rooms` (
	`id` text PRIMARY KEY NOT NULL,
	`state` text NOT NULL,
	`host_hash` text NOT NULL,
	`guest_hash` text,
	`host_name` text NOT NULL,
	`guest_name` text,
	`revision` integer DEFAULT 0 NOT NULL,
	`created` integer NOT NULL
);
