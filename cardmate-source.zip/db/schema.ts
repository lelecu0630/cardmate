import { integer, sqliteTable, text } from 'drizzle-orm/sqlite-core';
export const rooms = sqliteTable('rooms', {
  id: text('id').primaryKey(), state: text('state').notNull(),
  hostHash: text('host_hash').notNull(), guestHash: text('guest_hash'),
  hostName: text('host_name').notNull(), guestName: text('guest_name'),
  revision: integer('revision').notNull().default(0), created: integer('created').notNull(),
  visibility: text('visibility').notNull().default('private'),
  title: text('title').notNull().default(''),
  hostSeen: integer('host_seen').notNull().default(0),
});
