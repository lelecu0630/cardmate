"use client";

import { useCallback, useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight, BookOpen, Check, Globe, Hash, LockKeyhole, Plus, RefreshCw, Users } from 'lucide-react';
import type { Variant } from '@/lib/game';

type PublicRoom = {id:string;title:string;host:string;variant:Variant;created:number};
type Props = {
  tab: 'choose' | 'online' | 'create' | 'join';
  variant: Variant;
  name: string;
  code: string;
  busy: boolean;
  error: string;
  onTab: (tab: 'choose' | 'online' | 'create' | 'join') => void;
  onVariant: (variant: Variant) => void;
  onName: (name: string) => void;
  onCode: (code: string) => void;
  onLocal: () => void;
  onEnter: (op: 'create' | 'join', options?: {visibility:'public'|'private';title:string}) => void;
  onRules: () => void;
};

export default function StartScreen(props: Props) {
  const { tab, variant, name, code, busy, error, onTab, onVariant, onName, onCode, onLocal, onEnter, onRules } = props;
  const [play, setPlay] = useState<'online' | 'local'>('online');
  const [visibility, setVisibility] = useState<'public'|'private'>('public');
  const [title,setTitle] = useState('');
  const [rooms,setRooms] = useState<PublicRoom[]>([]),[listError,setListError]=useState(''),[loading,setLoading]=useState(false);
  const [joiningPublic,setJoiningPublic]=useState<PublicRoom|null>(null);
  const loadRooms=useCallback(async(signal?:AbortSignal)=>{
    try { const r=await fetch('/api/rooms?op=list',{cache:'no-store',signal});const d=await r.json() as {rooms:PublicRoom[];error?:string};if(!r.ok)throw new Error(d.error||'방 목록을 불러오지 못했어요.');if(!signal?.aborted){setRooms(d.rooms);setListError('');} }
    catch(e){if(!signal?.aborted)setListError(e instanceof Error?e.message:'방 목록을 불러오지 못했어요.');}
    finally{if(!signal?.aborted)setLoading(false);}
  },[]);
  useEffect(()=>{if(tab!=='online')return;const controller=new AbortController();setLoading(true);void loadRooms(controller.signal);const timer=setInterval(()=>void loadRooms(controller.signal),5000);return()=>{controller.abort();clearInterval(timer);};},[tab,loadRooms]);
  useEffect(()=>{if(tab!=='join'||!/^[A-Z0-9]{8}$/.test(code)){setJoiningPublic(null);return;}const controller=new AbortController();void fetch('/api/rooms?op=public&id='+code,{signal:controller.signal,cache:'no-store'}).then(async r=>r.ok?((await r.json()) as {room:PublicRoom}).room:null).then(room=>{if(room&&!controller.signal.aborted)setJoiningPublic(room);}).catch(()=>{});return()=>controller.abort();},[tab,code]);
  const privateJoin=()=>{setJoiningPublic(null);onCode('');onTab('join');};
  const classic = variant === 'classic';
  return <section className={`start-screen start-${tab}`} aria-label="게임 시작">
    <div className="start-intro">
      <span className="start-kicker"><span /> CHESS, WITH A TWIST</span>
      <h1>한 수의 전략,<br /><em>한 장의 반전.</em></h1>
      <p className="start-lead">익숙한 체스에 뜻밖의 한 장.<br />친구와 마주 앉아, 혹은 멀리서 한 판.</p>
      <div className="start-art" aria-hidden="true">
        <div className="art-orbit" />
        <div className="art-board">{Array.from({length: 36}, (_, i) => <span key={i} className={(Math.floor(i / 6) + i % 6) % 2 ? 'art-dark' : 'art-light'}>{i === 8 ? '♚︎' : i === 25 ? '♞︎' : ''}</span>)}</div>
        <div className="art-card art-card-reverse"><span>⇄</span><strong>⇄</strong><small>진영 교환</small></div>
        <div className="art-card art-card-number"><span>3</span><strong>3</strong><small>다음 수는 세 번</small></div>
        <div className="art-label"><span /> YOUR NEXT MOVE?</div>
      </div>
      <div className="start-footnote"><span>2인 대전</span><i /><span>가입 없이 바로</span><i /><span>백이 먼저 시작</span></div>
    </div>

    <div className="start-panel">
      {tab === 'choose' ? <>
        <div className="start-panel-heading"><div><span className="start-overline">LET’S PLAY</span><h2>오늘은 어떤 한 판?</h2></div><span className="start-heading-piece" aria-hidden="true">♞︎</span></div>
        <fieldset className="start-fieldset"><legend><span>01</span> 게임 선택</legend>
          <div className="start-variants">
            <button type="button" className={`start-variant ${!classic ? 'is-selected' : ''}`} aria-pressed={!classic} onClick={() => onVariant('cardmate')}>
              <div className="variant-art variant-art-card" aria-hidden="true"><span className="mini-card">⇄</span><span className="mini-knight">♞︎</span></div>
              <span className="variant-select-dot" aria-hidden="true">{!classic && <Check size={12} strokeWidth={3} />}</span>
              <span className="variant-title">카드메이트 <small>ORIGINAL</small></span><span className="variant-summary">카드 한 장으로<br />뒤집히는 수싸움</span>
            </button>
            <button type="button" className={`start-variant ${classic ? 'is-selected' : ''}`} aria-pressed={classic} onClick={() => onVariant('classic')}>
              <div className="variant-art variant-art-chess" aria-hidden="true"><span>♔︎</span><span>♚︎</span></div>
              <span className="variant-select-dot" aria-hidden="true">{classic && <Check size={12} strokeWidth={3} />}</span>
              <span className="variant-title">기본 체스</span><span className="variant-summary">한 번에 한 수,<br />정통 체스의 즐거움</span>
            </button>
          </div>
        </fieldset>
        <fieldset className="start-fieldset start-play-field"><legend><span>02</span> 대전 방식</legend>
          <div className="start-play-options">
            <button type="button" aria-pressed={play === 'online'} onClick={() => setPlay('online')}><Globe size={19} /><span>온라인 대전<small>공개방 또는 비밀방</small></span><span className="play-radio" aria-hidden="true" /></button>
            <button type="button" aria-pressed={play === 'local'} onClick={() => setPlay('local')}><Users size={19} /><span>한 화면 2인<small>같은 기기에서 함께</small></span><span className="play-radio" aria-hidden="true" /></button>
          </div>
        </fieldset>
        <button className="primary start-primary" disabled={busy} onClick={() => play === 'online' ? onTab('online') : onLocal()}>{play === 'online' ? '온라인 로비로' : '한 화면 대전 시작'}<ArrowRight size={19} /></button>
        <p className="start-selection-note">{classic ? '기본 체스' : '카드메이트'} · {play === 'online' ? '방을 만들거나 공개방에 참가하세요.' : '백부터 번갈아 플레이하세요.'}</p>
        <button className="start-join" onClick={privateJoin}><span className="join-hash"><LockKeyhole size={18} /></span><span><b>친구의 비밀방에 초대받았나요?</b><small>방 코드로 참가하기</small></span><ArrowRight size={17} /></button>
      </> : tab==='online' ? <>
        <button className="start-back text-button" onClick={()=>onTab('choose')}><ArrowLeft size={16}/>대전 선택으로</button>
        <span className="start-overline">PLAY TOGETHER</span><h2>온라인 로비</h2><p className="start-form-description">공개방에서 상대를 만나거나, 직접 방을 열어보세요.</p>
        <button className="primary lobby-create" onClick={()=>onTab('create')}><Plus size={19}/>새 방 만들기<small>{classic?'기본 체스':'카드메이트'}</small></button>
        <div className="public-list-heading"><h3>대기 중인 공개방 <span>{rooms.length}</span></h3><button className="text-button" disabled={loading} onClick={()=>{setLoading(true);void loadRooms();}} aria-label="공개방 새로고침"><RefreshCw size={14}/></button></div>
        <div className="public-rooms" aria-live="polite" aria-busy={loading}>
          {listError?<div className="rooms-empty" role="alert"><p>{listError}</p><button className="text-button" onClick={()=>void loadRooms()}>다시 불러오기</button></div>:loading&&!rooms.length?<div className="rooms-empty">공개방을 찾고 있어요…</div>:!rooms.length?<div className="rooms-empty"><Users size={27}/><b>아직 대기 중인 방이 없어요</b><p>첫 공개방을 만들고 상대를 기다려보세요.</p></div>:rooms.map(room=><button className="public-room" key={room.id} onClick={()=>{setJoiningPublic(room);onCode(room.id);onTab('join');}} aria-label={`${room.title} 참가하기`}><span className="room-piece" aria-hidden="true">{room.variant==='classic'?'♔':'♞'}</span><span className="room-information"><b>{room.title}</b><small>{room.host} · {room.variant==='classic'?'기본 체스':'카드메이트'}</small></span><span className="room-join-label">참가 <ArrowRight size={14}/></span></button>)}
        </div>
        <p className="rooms-note"><span/>접속 중인 방장의 빈자리만 표시해요 · 자동 갱신</p>
        <button className="start-join" onClick={privateJoin}><span className="join-hash"><LockKeyhole size={18}/></span><span><b>비밀방 참가</b><small>친구에게 받은 방 코드 입력</small></span><ArrowRight size={17}/></button>
      </> : <>
        <button className="start-back text-button" disabled={busy} onClick={() => onTab('online')}><ArrowLeft size={16} />온라인 로비로</button>
        <span className="start-overline">{tab === 'join' ? 'JOIN YOUR FRIEND' : 'INVITE YOUR FRIEND'}</span>
        <h2 className="start-form-title">{tab === 'join' ? joiningPublic?'공개방에 참가하기':'비밀방에 참가하기' : '새로운 한 판 만들기'}</h2>
        <p className="start-form-description">{tab === 'join' ? joiningPublic?'닉네임을 정하고 바로 대결에 합류하세요.':'닉네임과 친구에게 받은 방 코드를 입력하세요.' : '공개방에서 상대를 만나거나 비밀방으로 친구를 초대하세요.'}</p>
        <div className="start-room-summary">{tab === 'join' ? <>{joiningPublic?<Globe size={20}/>:<Hash size={20} />}<span><b>{joiningPublic?.title||'초대받은 게임으로 참가해요'}</b><small>{joiningPublic?`${joiningPublic.host} · ${joiningPublic.variant==='classic'?'기본 체스':'카드메이트'}`:'게임 종류는 방장이 선택한 설정을 따릅니다.'}</small></span></> : <><Globe size={20} /><span><b>{classic ? '기본 체스' : '카드메이트'} · 온라인 대전</b><small>방장은 백으로 먼저 시작해요.</small></span></>}</div>
        <form onSubmit={e => { e.preventDefault(); onEnter(tab === 'create' ? 'create' : 'join',{visibility,title}); }}>
          {tab==='create'&&<><fieldset className="start-fieldset visibility-field"><legend>방 공개 설정</legend><div className="start-play-options"><button type="button" aria-pressed={visibility==='public'} onClick={()=>setVisibility('public')}><Globe size={18}/><span>공개방<small>누구나 목록에서 참가</small></span></button><button type="button" aria-pressed={visibility==='private'} onClick={()=>setVisibility('private')}><LockKeyhole size={18}/><span>비밀방<small>코드 또는 링크로 참가</small></span></button></div></fieldset><label className="field-label" htmlFor="room-title">방 이름 <span className="optional-label">선택</span></label><input id="room-title" className="field" maxLength={40} placeholder="가볍게 한 판 하실 분!" value={title} disabled={busy} onChange={e=>setTitle(e.target.value)}/></>}
          <label className="field-label" htmlFor="player-name">내 닉네임 <span className="optional-label">선택</span></label>
          <input id="player-name" className="field" placeholder="플레이어" autoComplete="nickname" maxLength={20} value={name} disabled={busy} onChange={e => onName(e.target.value)} />
          {tab === 'join' && !joiningPublic && <><label className="field-label" htmlFor="room-input">방 코드</label><input id="room-input" className="field code-field" placeholder="8자리 방 코드" autoComplete="off" required maxLength={8} pattern="[A-Z0-9]{8}" value={code} disabled={busy} onChange={e => onCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))} /><p className="start-code-hint">영문과 숫자로 된 8자리 코드예요.</p></>}
          {tab==='create'&&<p className="create-visibility-note">{visibility==='public'?'방 이름과 닉네임이 공개방 목록에 표시돼요.':'목록에 표시되지 않아요. 코드나 링크를 아는 사람만 참가해요.'}</p>}
          <button className="primary start-primary" disabled={busy} type="submit">{busy ? '연결 중…' : tab === 'create' ? visibility==='public'?'공개방 만들기':'비밀방 만들기' : '방 참가하기'}{!busy && <ArrowRight size={19} />}</button>
        </form>
      </>}
      {error && <p className="error-message" role="alert">{error}</p>}
      <button className="start-rules text-button" onClick={onRules}><BookOpen size={15} />처음이라면, 플레이 방법 보기</button>
    </div>
  </section>;
}
