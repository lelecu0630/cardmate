"use client";
import StartScreen from './start-screen';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeftRight, BookOpen, Check, Copy, Flag, Globe, RotateCcw, Users, Volume2, VolumeX, X } from 'lucide-react';
import { newGame, transition, availableMoves, availableWild, inCheck, protectedOpening, isClassic, cardLabel, squareName, pieceNames, type Game, type Action, type Card, type Kind, type Variant } from '@/lib/game';
type RoomView={id:string;state:Game;revision:number;seat:number;players:[string,string];waiting:boolean;visibility?:'public'|'private';title?:string};
const glyphs:Record<string,string>={wk:'♚',wq:'♛',wr:'♜',wb:'♝',wn:'♞',wp:'♟',bk:'♚',bq:'♛',br:'♜',bb:'♝',bn:'♞',bp:'♟'};
const promos:Kind[]=['q','r','b','n'];
const randomToken=()=>Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');
function CardFace({card,back=false,animate=false}:{card:Card|null;back?:boolean;animate?:boolean}){
  const value=back?'♞':card?.kind==='number'?card.value:card?.kind==='reverse'?'⇄':card?.kind==='skip'?'⊘':card?.kind==='wild'?'♟':card?.kind==='plus2'?'+2':'+4';
  return <div className={`game-card ${back?'card-back':`card-${card?.color||'green'}`} ${animate?'reveal':''}`} aria-hidden="true"><span className="card-corner">{back?'CM':value}</span><div className="card-oval">{back?<b>CARD<br/>MATE</b>:<strong>{value}</strong>}</div><span className="card-corner corner-bottom">{back?'CM':value}</span></div>;
}
function Modal({children,onClose,label}:{children:React.ReactNode;onClose?:()=>void;label:string}){
  const ref=useRef<HTMLDivElement>(null);
  useEffect(()=>{const previous=document.activeElement as HTMLElement|null;const root=ref.current;root?.querySelector<HTMLElement>('button,input')?.focus();const key=(e:KeyboardEvent)=>{if(e.key==='Escape'&&onClose)onClose();if(e.key==='Tab'&&root){const els=Array.from(root.querySelectorAll<HTMLElement>('button:not(:disabled),input,a[href]'));if(!els.length)return;const first=els[0],last=els[els.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}};document.addEventListener('keydown',key);return()=>{document.removeEventListener('keydown',key);previous?.focus();};},[onClose]);
  return <div className="modal-backdrop"><div className="modal" ref={ref} role="dialog" aria-modal="true" aria-label={label}>{onClose&&<button className="icon-button close-button" onClick={onClose} aria-label="닫기"><X size={20}/></button>}{children}</div></div>;
}
const rules=[
  ['기본 진행','체스와 같은 말·배치·이동 규칙입니다. 매 턴 중앙 더미에서 카드 한 장을 뽑습니다. 숫자만큼 최대 이동할 수 있고, 같은 말을 반복해서 움직일 수 있습니다.'],
  ['체크와 승리','왕을 체크에 노출시키는 수는 불가능합니다. 상대에게 체크하면 남은 이동은 종료됩니다. 체크메이트하면 승리합니다. 두 사람 모두 첫 턴을 마치기 전에는 체크메이트가 되는 수와 폰 변경을 할 수 없습니다.'],
  ['체크 방어','체크 상태에서는 첫 이동으로 방어해야 합니다. 0이나 특수카드를 뽑아도 방어용 1회를 보장합니다. 특수카드는 방어 후 적용합니다. 방어하며 상대를 체크하면 특수 효과 없이 턴이 종료됩니다.'],
  ['숫자 0~9','숫자 + 저장된 보너스만큼 이동합니다. 보너스 없는 0은 턴을 종료합니다. 이동 도중 원하는 때 종료할 수 있습니다.'],
  ['+2 · +4','이번 턴은 종료하고 자신의 다음 숫자 카드에 이동 보너스를 저장합니다. 보너스는 누적되고, 다른 특수카드를 뽑아도 유지됩니다. 진영을 교환해도 보너스는 플레이어에게 남습니다.'],
  ['진영 교환 · 건너뛰기','진영 교환은 백·흑 조종권을 바꾼 뒤 상대 차례로 넘어갑니다. 말의 위치는 그대로입니다. 건너뛰기는 상대 차례를 생략하고 자신이 다시 카드를 뽑습니다.'],
  ['와일드: 폰 변경','자신의 폰 하나를 현재 위치에서 퀸·룩·비숍·나이트로 변경하고 턴을 종료합니다. 변경할 폰이 없으면 종료합니다. +4는 폰 변경 없이 이동 보너스만 저장합니다.'],
  ['체스 특수 규칙','캐슬링은 1회 이동입니다. 끝줄에 도착한 폰은 원하는 말로 승격합니다. 앙파상은 폰의 2칸 이동 직후 다음 기물 이동에만 가능합니다. 연속 이동에서도 각 이동을 따로 판정합니다.'],
  ['무승부 · 카드 더미','스테일메이트, 같은 턴 시작 국면 3회 반복, 잡기·폰 이동 없이 100회 이동, 기본적인 기물 부족이면 무승부입니다. 108장 더미를 쓰며 색깔에는 추가 효과가 없습니다. 다 쓰면 사용한 카드를 섞습니다.'],
  ['온라인 방','공개방은 온라인 로비에서, 비밀방은 코드나 링크로 참가합니다. 방은 24시간 유지됩니다. 새로고침해도 같은 탭에서 재접속할 수 있습니다. 기권은 자신의 차례에 가능합니다. 첫 버전에는 턴 제한시간이 없습니다.'],
];
const classicRules=[
  ['백이 먼저 시작','백이 먼저 움직이고, 한 번의 이동마다 백과 흑이 번갈아 진행합니다. 카드 뽑기와 첫 턴 보호는 적용하지 않습니다.'],
  ['말의 이동','각 말의 체스 이동·잡기 규칙을 따릅니다. 자신의 왕을 체크에 노출시키는 이동은 할 수 없습니다. 보드에 표시된 이동 가능 칸을 선택하세요.'],
  ['체크와 체크메이트','체크를 받으면 이번 수로 해소해야 합니다. 합법적인 방어가 없는 체크메이트로 승리하며, 왕을 직접 잡지는 않습니다.'],
  ['캐슬링 · 앙파상 · 승격','왕과 룩의 첫 이동 여부와 체크 경로를 검증해 캐슬링합니다. 앙파상은 상대 폰의 2칸 전진 직후 자신의 다음 수에 가능합니다. 끝줄 폰은 퀸·룩·비숍·나이트 중 선택해 승격합니다.'],
  ['무승부','스테일메이트, 체크메이트할 기물 부족, 동일 국면 3회 반복, 잡기·폰 이동 없이 100회 이동을 자동으로 판정합니다.'],
  ['온라인 대전','공개방은 목록에서, 비밀방은 코드나 링크로 참가합니다. 방장이 선택한 게임 종류로 진행합니다. 방은 24시간 유지되고 같은 탭에서 새로고침하면 재접속합니다. 첫 버전에는 제한시간이 없습니다.'],
];
export default function Home(){
  const [g,setG]=useState<Game|null>(null),[mode,setMode]=useState<'local'|'online'|null>(null),[room,setRoom]=useState<RoomView|null>(null);
  const [setup,setSetup]=useState(true),[setupTab,setSetupTab]=useState<'choose'|'online'|'create'|'join'>('choose'),[name,setName]=useState(''),[code,setCode]=useState('');
  const [variant,setVariant]=useState<Variant>('cardmate');
  const [selected,setSelected]=useState<number|null>(null),[promotion,setPromotion]=useState<{from:number;to?:number;wild:boolean}|null>(null);
  const [showRules,setShowRules]=useState(false),[confirm,setConfirm]=useState<'reset'|'resign'|'leave'|null>(null),[busy,setBusy]=useState(false),[error,setError]=useState(''),[toast,setToast]=useState(''),[copied,setCopied]=useState(false),[flip,setFlip]=useState(false),[sound,setSound]=useState(false),[lastReveal,setLastReveal]=useState(0);
  const token=useRef(''),revision=useRef(-1),gameRef=useRef<Game|null>(null),roomRef=useRef<RoomView|null>(null),busyRef=useRef(false),soundRef=useRef(false),audio=useRef<AudioContext|null>(null),sessionInitialized=useRef(false);
  const playReady=useRef(false);playReady.current=!!mode&&!setup;
  gameRef.current=g;roomRef.current=room;soundRef.current=sound;
  const beep=useCallback(()=>{if(!soundRef.current)return;try{audio.current??=new AudioContext();const a=audio.current;if(a.state==='suspended')void a.resume();const o=a.createOscillator(),v=a.createGain();o.connect(v);v.connect(a.destination);o.frequency.setValueAtTime(620,a.currentTime);v.gain.setValueAtTime(.04,a.currentTime);v.gain.exponentialRampToValueAtTime(.001,a.currentTime+.12);o.start();o.stop(a.currentTime+.12);}catch{}},[]);
  const accept=useCallback((data:RoomView)=>{if(data.revision<revision.current)return;revision.current=data.revision;roomRef.current=data;gameRef.current=data.state;setRoom(data);setG(data.state);setVariant(data.state.variant||'cardmate');setSelected(null);setPromotion(null);setMode('online');setSetup(false);},[]);
  useEffect(()=>{setG(newGame());if(sessionInitialized.current)return;sessionInitialized.current=true;const id=new URLSearchParams(location.search).get('room');if(!id)return;const normalized=id.toUpperCase();setCode(normalized);setSetupTab('join');const saved=sessionStorage.getItem('cardmate-token-'+normalized);if(saved){token.current=saved;setBusy(true);fetch('/api/rooms?id='+encodeURIComponent(normalized),{headers:{Authorization:'Bearer '+saved}}).then(async r=>{const d=(await r.json()) as RoomView & {error:string};if(!r.ok)throw new Error(d.error);accept(d);}).catch(e=>setError(e.message)).finally(()=>setBusy(false));}},[accept]);
  useEffect(()=>{if(mode!=='online'||!room?.id)return;let stopped=false,errors=0;const id=room.id;const poll=async()=>{if(stopped||busyRef.current)return;try{const r=await fetch('/api/rooms?id='+id,{headers:{Authorization:'Bearer '+token.current},cache:'no-store'});const d=(await r.json()) as RoomView & {error:string};if(!r.ok)throw new Error(d.error);errors=0;if(!stopped&&d.revision>revision.current){accept(d);beep();}if(!stopped)setError('');}catch(e){errors++;if(errors>=3&&!stopped)setError(e instanceof Error?e.message:'연결이 끊겼습니다. 자동으로 재접속 중입니다.');}};const timer=setInterval(poll,1200);void poll();return()=>{stopped=true;clearInterval(timer);};},[mode,room?.id,accept,beep]);
  useEffect(()=>{if(!toast)return;const timer=setTimeout(()=>setToast(''),3000);return()=>clearTimeout(timer);},[toast]);
  const act=useCallback(async(action:Action)=>{
    const current=gameRef.current;if(!current||busyRef.current)return;
    setError('');setSelected(null);setPromotion(null);
    try{
      if(roomRef.current){busyRef.current=true;setBusy(true);const r=await fetch('/api/rooms',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({op:'action',id:roomRef.current.id,token:token.current,revision:revision.current,action})});const d=(await r.json()) as RoomView & {error:string};if(!r.ok)throw new Error(d.error);accept(d);}
      else{const next=transition(current,action);setG(next);gameRef.current=next;}
      if(action.type==='draw')setLastReveal(Date.now());beep();return {ok:true};
    }catch(e){const msg=e instanceof Error?e.message:'진행하지 못했습니다.';setError(msg);throw new Error(msg);}
    finally{busyRef.current=false;setBusy(false);}
  },[accept,beep]);
  const send=(action:Action)=>{void act(action).catch(()=>{});};
  useEffect(()=>{const context=(document as unknown as {modelContext?:{registerTool:(t:unknown,o:unknown)=>unknown}}).modelContext;if(!context?.registerTool)return;const lifecycle=new AbortController();
    const register=(tool:unknown)=>{try{void Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}};
    register({name:'read_cardmate_game',description:'Read the current visible board, phase, active player and remaining moves.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true},execute:()=>{const s=gameRef.current;return s?{board:s.position.board.map((p,i)=>p?{square:squareName(i),...p}:null).filter(Boolean),phase:s.phase,activePlayer:s.active+1,remaining:s.remaining,result:s.result}: {status:'not_started'};}});
    register({name:'draw_cardmate_card',description:'Draw one central card in an already started game during your draw phase.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:false},execute:async()=>{if(!playReady.current)throw new Error('Start a game first');const r=roomRef.current;if(r&&(r.waiting||r.seat!==gameRef.current?.active))throw new Error('Not your turn');return act({type:'draw'});}});
    return()=>lifecycle.abort();
  },[act]);
  const enter=async(op:'create'|'join',options?:{visibility:'public'|'private';title:string})=>{if(busyRef.current)return;setError('');busyRef.current=true;setBusy(true);try{const t=op==='join'?sessionStorage.getItem('cardmate-token-'+code)||randomToken():randomToken();const r=await fetch('/api/rooms',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({op,id:code.trim().toUpperCase(),token:t,name:name.trim()||'플레이어',variant,...(op==='create'?options:{})})});const d=(await r.json()) as RoomView & {error:string};if(!r.ok)throw new Error(d.error);token.current=t;sessionStorage.setItem('cardmate-token-'+d.id,t);revision.current=-1;accept(d);history.replaceState(null,'','?room='+d.id);}catch(e){setError(e instanceof Error?e.message:'입장하지 못했습니다.');}finally{busyRef.current=false;setBusy(false);}};
  const localStart=()=>{setG(newGame(variant));setMode('local');setRoom(null);revision.current=-1;setSetup(false);setError('');setSelected(null);setPromotion(null);history.replaceState(null,'',location.pathname);};
  const invite=async()=>{if(!room)return;const link=location.origin+location.pathname+'?room='+room.id;try{await navigator.clipboard.writeText(link);setCopied(true);setTimeout(()=>setCopied(false),2500);}catch{setToast('방 코드 '+room.id+'를 친구에게 알려주세요.');}};
  const canAct=!!g&&!setup&&!busy&&g.phase!=='over'&&(!room||(!room.waiting&&room.seat===g.active));
  const classic=g?isClassic(g):variant==='classic';
  const moves=g&&['move','defend'].includes(g.phase)?availableMoves(g):[];
  const targets=selected===null?[]:moves.filter(m=>m.from===selected).map(m=>m.to);
  const myColor=g?(room?g.colors[room.seat]:g.colors[g.active]):'w';
  const orientation=(room?myColor==='b':false)!==flip;
  const cells=Array.from({length:64},(_,i)=>orientation?63-i:i);
  const players: [string,string]=room?.players||['플레이어 1','플레이어 2'];
  const bottom=g?g.colors.indexOf(orientation?'b':'w'):0,top=1-bottom;
  const checkedColor=g?(inCheck(g.position,'w')?'w':inCheck(g.position,'b')?'b':null):null;
  const clickSquare=(at:number)=>{if(!g||!canAct)return;const p=g.position.board[at];
    if(g.phase==='wild'){if(p?.color===myColor&&p.kind==='p')setPromotion({from:at,wild:true});else setToast('내 폰을 선택하세요.');return;}
    if(!['move','defend'].includes(g.phase)){setToast('먼저 중앙 더미에서 카드를 뽑으세요.');return;}
    if(selected!==null&&targets.includes(at)){
      const options=moves.filter(m=>m.from===selected&&m.to===at);if(options.some(m=>m.promotion))setPromotion({from:selected,to:at,wild:false});else send({type:'move',from:selected,to:at});return;
    }
    if(p?.color===myColor){setSelected(selected===at?null:at);if(!moves.some(m=>m.from===at))setToast('이 말은 지금 이동할 수 없습니다.');}else setSelected(null);
  };
  const playerRow=(i:number)=>{const color=g?.colors[i]||'w',active=g?.active===i;return <div className={`player-row ${active?'player-active':''}`} data-player={i}><span className={`avatar ${color==='w'?'white-avatar':'black-avatar'}`} role="img" aria-label={`${players[i]} · ${color==='w'?'백':'흑'} 킹 아이콘`} data-color={color}>{color==='w'?'♔\uFE0E':'♚\uFE0E'}</span><div className="player-name"><b>{players[i]}{room?.seat===i&&<span className="you-label">나</span>}</b><small>{color==='w'?'백':'흑'} 진영{active?' · 현재 차례':''}</small></div>{!!g?.bonuses[i]&&<span className="bonus-pill">다음 이동 +{g.bonuses[i]}</span>}{active&&<span className="turn-pill">TURN</span>}</div>};
  const cardText=!g?.card?'중앙 더미에서 한 장 뽑으세요.':g.card.kind==='number'?`${g.card.value}회 이동 카드`:g.card.kind==='plus2'||g.card.kind==='plus4'?'다음 숫자 카드에 보너스 저장':g.card.kind==='reverse'?'백·흑 조종권 교환':g.card.kind==='skip'?'상대 차례 건너뛰기':'내 폰 하나를 원하는 말로 변경';
  return <main className={`shell ${setup ? 'lobby-shell' : ''}`}><header className="topbar"><a className="brand" href="/" onClick={e=>{if(mode){e.preventDefault();setConfirm('leave');}}}>♞ <span>카드메이트<small>CARDMATE</small></span></a><nav><span className="tag">{classic?'기본 체스':'체스 × 카드'}</span><button className="nav-button" onClick={()=>setShowRules(true)}><BookOpen size={17}/>게임 규칙</button><button className="icon-button" aria-label={sound?'소리 끄기':'소리 켜기'} onClick={()=>setSound(!sound)}>{sound?<Volume2 size={18}/>:<VolumeX size={18}/>}</button></nav></header>
  {!setup&&<>
  <div className="game-toolbar"><div className="mode-label">{mode==='online'?<Globe size={15}/>:<Users size={15}/>} {mode==='online'?'온라인 대전':'한 화면 2인'}<span className="variant-badge">{classic?'기본 체스':'카드메이트'}</span>{room&&<><span className="variant-badge">{room.visibility==='public'?'공개방':'비밀방'}</span><span className="room-code">{room.id}</span></>}</div><div className="toolbar-actions">{room&&<button className="text-button" onClick={invite}>{copied?<Check size={15}/>:<Copy size={15}/>}초대 링크 {copied?'복사됨':'복사'}</button>}<button className="text-button" onClick={()=>setFlip(!flip)}><ArrowLeftRight size={15}/>보드 회전</button><button className="text-button" onClick={()=>setConfirm(mode==='online'?'leave':'reset')}><RotateCcw size={15}/>새 게임</button></div></div>
  <section className="arena"><div className="board-column">{playerRow(top)}<div className="board" role="group" aria-label="체스판">{cells.map((at,index)=>{const p=g?.position.board[at],r=Math.floor(at/8),c=at%8,last=g?.lastMove?.includes(at),target=targets.includes(at),checked=p?.kind==='k'&&p.color===checkedColor;return <button key={at} className={`square ${(r+c)%2?'dark':'light'} ${selected===at?'selected':''} ${last?'last-move':''} ${checked?'checked':''} ${g?.phase==='wild'&&p?.kind==='p'&&p.color===myColor&&canAct?'wild-pawn':''}`} onClick={()=>clickSquare(at)} aria-label={`${squareName(at)}${p?' '+(p.color==='w'?'백':'흑')+' '+pieceNames[p.kind]:' 빈 칸'}${target?' 이동 가능':''}`} aria-pressed={selected===at}>{index%8===0&&<span className="coordinate rank">{8-r}</span>}{index>=56&&<span className="coordinate file">{'abcdefgh'[c]}</span>}{p&&<span className={`piece ${p.color==='w'?'white-piece':'black-piece'}`}>{glyphs[p.color+p.kind]}</span>}{target&&<span className={p?'capture-target':'move-target'}/>}</button>;})}</div>{playerRow(bottom)}<div className="board-footer"><span>{classic?'백 선공 · 한 턴에 한 번 이동':g&&protectedOpening(g)?'첫 턴 체크메이트 보호 중':'첫 턴 보호 해제'}{g?.phase==='over'?' · 게임 종료':''}</span><span>{g?.captured.length||0}개 잡음</span></div></div>
  <aside className="side game-side"><div className="turn-heading"><span className="eyebrow">{room?.waiting?'WAITING FOR FRIEND':g?.phase==='over'?'GAME OVER':canAct?'YOUR TURN':'OPPONENT’S TURN'}</span><h1>{room?.waiting?(room.visibility==='public'?'상대를 기다리는 중':'친구를 기다리는 중'):g?.phase==='over'?'승부가 끝났어요':`${players[g?.active||0]}의 차례`}</h1></div>
  {classic?<div className="classic-panel"><span className="classic-king" aria-hidden="true">{g?.colors[g.active]==='b'?'♚\uFE0E':'♔\uFE0E'}</span><h2>{g?.colors[g.active]==='b'?'흑':'백'}이 움직일 차례</h2><p>말을 선택하고<br/>이동할 칸을 누르세요.</p><span>한 번 이동하면 상대 차례로 넘어갑니다.</span></div>:<><div className="card-table"><button className="deck-button" disabled={!canAct||g?.phase!=='draw'} onClick={()=>send({type:'draw'})} aria-label="중앙 더미에서 카드 뽑기"><CardFace card={null} back/><span className="deck-caption">카드 더미 <b>{g?.deckLeft??108}</b></span></button><div className="discard-area">{g?.card?<div key={lastReveal||g.logs.length}><CardFace card={g.card} animate/></div>:<div className="empty-card">?<span>다음 한 장은?</span></div>}<span className="deck-caption">{g?.card?cardLabel(g.card):'공개 카드'}</span></div></div>
  <p className="card-description">{cardText}</p>
  <div className="moves-meter"><div><span>남은 이동</span><strong>{['move','defend'].includes(g?.phase||'')?g?.remaining:'—'}<small>회</small></strong></div><span className="meter-label">{g?.phase==='wild'?'폰을 선택하세요':g?.phase==='defend'?'체크 방어 먼저':g?.phase==='draw'?'카드를 뽑을 차례':'같은 말도 연속 이동'}</span></div>
  </>}
  <div className="game-status" role="status" aria-live="polite">{room?.waiting?(room.visibility==='public'?'공개방 목록에 표시 중이에요. 상대가 참가하면 시작합니다.':'초대 링크나 방 코드를 친구에게 보내주세요.'):room&&room.seat!==g?.active&&g?.phase!=='over'?'상대가 다음 수를 생각하고 있어요.':g?.notice}</div>
  {room?.waiting?<button className="primary" onClick={invite}>{copied?'링크를 복사했어요':'친구 초대 링크 복사'}</button>:classic?<div className="classic-action-hint">{busy?'이동 처리 중…':g?.phase==='over'?'게임 종료':canAct?'보드에서 내 말을 선택하세요':'상대의 이동을 기다리는 중'}</div>:<button className="primary" disabled={!canAct||!['draw','move'].includes(g?.phase||'')} onClick={()=>send({type:g?.phase==='draw'?'draw':'end'})}>{busy?'처리 중…':g?.phase==='draw'?'카드 뽑기':g?.phase==='wild'?'내 폰을 눌러 변경하기':g?.phase==='defend'?'체크를 먼저 해소하세요':g?.phase==='over'?'게임 종료':'턴 종료'}</button>}
  {error&&<div className="error-message" role="alert">{error}</div>}
  <div className="history-panel"><div className="history-title"><h2>게임 기록</h2><span>{g?.logs.length||0}</span></div><ol>{g?.logs.slice(-5).reverse().map((entry,i)=><li key={`${g.logs.length}-${i}`}><span className="history-index">{String(g.logs.length-i).padStart(2,'0')}</span>{entry}</li>)}</ol></div>
  <div className="side-bottom"><span>{classic?'기본 체스 규칙 적용':'체크하면 남은 이동 종료'}</span>{mode&&g?.phase!=='over'&&<button className="text-button" disabled={!canAct} onClick={()=>setConfirm('resign')}><Flag size={14}/>기권</button>}</div></aside></section>
  <footer className="site-footer"><span>CARDMATE</span><span>좋은 수에, 뜻밖의 한 장.</span></footer>
  </>}
  {toast&&<div className="toast" role="status">{toast}</div>}
  {setup&&<><StartScreen tab={setupTab} variant={variant} name={name} code={code} busy={busy} error={error} onTab={tab=>{setSetupTab(tab);setError('');}} onVariant={v=>{setVariant(v);setG(newGame(v));}} onName={setName} onCode={setCode} onLocal={localStart} onEnter={(op,options)=>{void enter(op,options);}} onRules={()=>setShowRules(true)}/><footer className="lobby-footer"><span>CARDMATE</span><span>좋은 수에, 뜻밖의 한 장.</span></footer></>}
  {showRules&&<Modal label="게임 규칙" onClose={()=>setShowRules(false)}><div className="eyebrow">HOW TO PLAY</div><h2 className="compact-title">{classic?'기본 체스 규칙':'카드메이트 규칙'}</h2><div className="rules-scroll">{(classic?classicRules:rules).map(([title,text],i)=><section className="rule-item" key={title}><span>{String(i+1).padStart(2,'0')}</span><div><h3>{title}</h3><p>{text}</p></div></section>)}</div><button className="primary" onClick={()=>setShowRules(false)}>확인</button></Modal>}
  {promotion&&g&&<Modal label={promotion.wild?'폰 변경':'폰 승격'} onClose={()=>setPromotion(null)}><div className="eyebrow">{promotion.wild?'WILD CARD':'PROMOTION'}</div><h2 className="compact-title">{squareName(promotion.from)} 폰을<br/>어떤 말로 바꿀까요?</h2><div className="promotion-grid">{promos.map(kind=>{const allowed=promotion.wild?availableWild(g,promotion.from,kind):moves.some(m=>m.from===promotion.from&&m.to===promotion.to&&m.promotion===kind);return <button key={kind} disabled={!allowed||busy} onClick={()=>send(promotion.wild?{type:'wild',from:promotion.from,promotion:kind}:{type:'move',from:promotion.from,to:promotion.to,promotion:kind})}><span>{glyphs[myColor+kind]}</span><b>{pieceNames[kind]}</b></button>;})}</div><p className="modal-description">{protectedOpening(g)?'첫 턴 보호 중에는 체크메이트가 되는 변경은 불가능합니다.':promotion.wild?'현재 폰의 위치에서 바로 변경됩니다.':'끝줄에 도착한 폰을 원하는 말로 승격합니다.'}</p></Modal>}
  {confirm&&<Modal label="게임 확인" onClose={()=>setConfirm(null)}><h2 className="compact-title">{confirm==='resign'?'기권할까요?':confirm==='leave'?(mode==='online'?'현재 방을 나갈까요?':'대전 선택으로 돌아갈까요?'):'새 게임을 시작할까요?'}</h2><p className="modal-description">{confirm==='resign'?'상대의 승리로 이번 게임이 종료됩니다.':confirm==='leave'?(mode==='online'?'진행 중인 방은 유지됩니다. 초대 링크로 다시 입장할 수 있어요.':'진행 중인 한 화면 게임이 종료됩니다.'):'현재 판을 끝내고 처음 배치로 돌아갑니다.'}</p><div className="dialog-actions"><button className="secondary" onClick={()=>setConfirm(null)}>계속 플레이</button><button className="primary" onClick={()=>{const choice=confirm;setConfirm(null);if(choice==='resign')send({type:'resign'});else if(choice==='reset')localStart();else{if(room?.seat===0&&room.waiting)void fetch('/api/rooms',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({op:'leave',id:room.id,token:token.current})}).catch(()=>{});setMode(null);setRoom(null);setSetup(true);setSetupTab('choose');setG(newGame(variant));setSelected(null);setPromotion(null);setError('');history.replaceState(null,'',location.pathname);}}}>{confirm==='resign'?'기권하기':confirm==='leave'?'나가기':'새 게임'}</button></div></Modal>}
  {g?.phase==='over'&&!setup&&!confirm&&<div className="result-banner" role="status"><div><span className="eyebrow">{g.winner===null?'DRAW':'CHECKMATE / GAME OVER'}</span><strong>{g.result}</strong></div><button className="primary" onClick={()=>mode==='online'?setConfirm('leave'):localStart()}>다음 게임</button></div>}
  </main>;
}


