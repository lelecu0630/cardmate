import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "카드메이트 · 체스 × 카드",
  description: "카드 한 장이 바꾸는 체스. 친구와 온라인으로 또는 한 화면에서 즐기는 2인 게임.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body className="antialiased">{children}</body>
    </html>
  );
}
