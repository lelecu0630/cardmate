import { database } from '@/lib/database';
import { newGame, transition, type Game, type Action } from '@/lib/game';

type Room={id:string;state:string;host_hash:string;guest_hash:string|null;host_name:string;guest_name:string|null;revision:number;created:number;visibility:string;title:string;host_seen:number};
const reply=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
const hash=async(s:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)))).map(b=>b.toString(16).padStart(2,'0')).join('');
const roomLifetime=86400000, presenceLifetime=90000;
function validateId(id:unknown){if(typeof id!=='string'||!/^[A-Z0-9]{8}$/.test(id))throw new Error('방 코드는 영문과 숫자 8자리입니다.');}
function validate(id:unknown,token:unknown){validateId(id);if(typeof token!=='string'||!/^[a-f0-9]{64}$/.test(token))throw new Error('참가 정보가 유효하지 않습니다. 방에 다시 입장하세요.');}
async function find(id:string){const room=await database().prepare('SELECT * FROM rooms WHERE id = ?').bind(id).first<Room>();if(!room||Date.now()-room.created>roomLifetime)throw new Error('방을 찾을 수 없거나 만료되었습니다. 새 방을 만들어주세요.');return room;}
function seat(room:Room,h:string){if(h===room.host_hash)return 0;if(h===room.guest_hash)return 1;throw new Error('이 방의 참가자가 아닙니다.');}
function view(room:Room,player:number){const g=JSON.parse(room.state) as Game;return {id:room.id,state:{...g,deck:[]},revision:room.revision,seat:player,players:[room.host_name,room.guest_name||'상대 입장 대기'],waiting:!room.guest_hash,visibility:room.visibility,title:room.title};}
function publicSummary(room:Pick<Room,'id'|'title'|'host_name'|'created'|'state'>){const g=JSON.parse(room.state) as Game;return {id:room.id,title:room.title||`${room.host_name}의 한 판`,host:room.host_name,variant:g.variant||'cardmate',created:room.created};}
export async function GET(req:Request){try{
  const url=new URL(req.url),op=url.searchParams.get('op'),db=database();
  if(op==='list'){
    const rooms=await db.prepare("SELECT id, title, host_name, created, state FROM rooms WHERE visibility='public' AND guest_hash IS NULL AND created>? AND host_seen>? ORDER BY created DESC LIMIT 30").bind(Date.now()-roomLifetime,Date.now()-presenceLifetime).all<Pick<Room,'id'|'title'|'host_name'|'created'|'state'>>();
    return reply({rooms:rooms.results.map(publicSummary)});
  }
  const id=url.searchParams.get('id')||'';
  if(op==='public'){
    validateId(id);const room=await find(id);
    if(room.visibility!=='public'||room.guest_hash||Date.now()-room.host_seen>presenceLifetime)return reply({error:'참가 가능한 공개방이 아닙니다.'},404);
    return reply({room:publicSummary(room)});
  }
  const token=req.headers.get('Authorization')?.replace(/^Bearer /,'')||'';validate(id,token);
  const room=await find(id),player=seat(room,await hash(token));
  if(player===0&&Date.now()-room.host_seen>20000)await db.prepare('UPDATE rooms SET host_seen=? WHERE id=? AND host_seen<?').bind(Date.now(),id,Date.now()-20000).run();
  return reply(view(room,player));
}catch(e){return reply({error:e instanceof Error?e.message:'방을 불러오지 못했습니다.'},400);}}
export async function POST(req:Request){
  try{
    const origin=req.headers.get('Origin');if(origin&&origin!==new URL(req.url).origin)return reply({error:'다른 사이트에서 요청할 수 없습니다.'},403);
    const body=await req.json() as {op:string;id:string;token:string;name?:string;revision?:number;action?:Action;variant?:string;visibility?:string;title?:string};
    validate(body.op==='create'?'AAAAAAAA':body.id,body.token);const h=await hash(body.token),db=database();
    const name=(typeof body.name==='string'?body.name.trim():'').slice(0,20)||'플레이어';
    if(body.op==='create'){
      if(body.variant!==undefined&&!['cardmate','classic'].includes(body.variant))throw new Error('게임 종류를 다시 선택하세요.');
      if(body.visibility!==undefined&&!['public','private'].includes(body.visibility))throw new Error('공개 여부를 다시 선택하세요.');
      const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',bytes=crypto.getRandomValues(new Uint8Array(8));
      const id=Array.from(bytes,b=>alphabet[b%alphabet.length]).join(''),now=Date.now();
      const room:Room={id,state:JSON.stringify(newGame(body.variant==='classic'?'classic':'cardmate')),host_hash:h,guest_hash:null,host_name:name,guest_name:null,revision:0,created:now,visibility:body.visibility||'public',title:(typeof body.title==='string'?body.title.trim():'').slice(0,40)||`${name}의 한 판`,host_seen:now};
      await db.prepare('INSERT INTO rooms (id,state,host_hash,host_name,revision,created,visibility,title,host_seen) VALUES (?,?,?,?,?,?,?,?,?)').bind(id,room.state,h,name,0,room.created,room.visibility,room.title,now).run();
      return reply(view(room,0));
    }
    let room=await find(body.id);
    if(body.op==='leave'){
      if(seat(room,h)===0&&!room.guest_hash)await db.prepare('UPDATE rooms SET host_seen=0 WHERE id=?').bind(body.id).run();
      return reply({ok:true});
    }
    if(body.op==='join'){
      if(h===room.host_hash||h===room.guest_hash)return reply(view(room,seat(room,h)));
      if(room.guest_hash)return reply({error:'이미 두 명이 참가한 방입니다.'},409);
      if(room.visibility==='public'&&Date.now()-room.host_seen>presenceLifetime)return reply({error:'방장이 자리를 비웠어요. 공개방 목록에서 다른 방을 골라주세요.'},409);
      const result=await db.prepare("UPDATE rooms SET guest_hash=?, guest_name=?, revision=revision+1 WHERE id=? AND guest_hash IS NULL AND (visibility!='public' OR host_seen>?)").bind(h,name,body.id,Date.now()-presenceLifetime).run();
      if(!result.meta.changes)return reply({error:'다른 사람이 먼저 입장했습니다.'},409);
      room=await find(body.id);return reply(view(room,1));
    }
    if(body.op!=='action'||!body.action)return reply({error:'올바른 게임 행동이 아닙니다.'},400);
    const player=seat(room,h),game=JSON.parse(room.state) as Game;
    if(!room.guest_hash)return reply({error:'상대가 입장하면 시작할 수 있습니다.'},400);
    if(game.active!==player)return reply({error:'상대의 차례입니다.'},403);
    if(body.revision!==room.revision)return reply({error:'판이 변경되었습니다. 최신 상태를 불러옵니다.'},409);
    const next=transition(game,body.action);
    const result=await db.prepare('UPDATE rooms SET state=?, revision=revision+1 WHERE id=? AND revision=?').bind(JSON.stringify(next),body.id,room.revision).run();
    if(!result.meta.changes)return reply({error:'판이 변경되었습니다. 다시 시도해주세요.'},409);
    room={...room,state:JSON.stringify(next),revision:room.revision+1};return reply(view(room,player));
  }catch(e){console.error('Room request failed:',e instanceof Error?e.message:'unknown');return reply({error:e instanceof Error?e.message:'온라인 대전을 연결하지 못했습니다. 잠시 후 다시 시도해주세요.'},400);}
}
