export type Color = 'w' | 'b';
export type Variant = 'cardmate' | 'classic';
export type Kind = 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
export type Piece = { color: Color; kind: Kind };
export type Move = { from: number; to: number; promotion?: Kind; castle?: 'k' | 'q'; ep?: boolean };
export type Position = { board: (Piece | null)[]; rights: string; ep: number | null; halfmove: number };
export type Card = { kind: 'number' | 'reverse' | 'skip' | 'plus2' | 'plus4' | 'wild'; value: number; color: string };
export type Game = {
  variant?: Variant;
  position: Position; colors: [Color, Color]; active: number; completed: [number, number];
  bonuses: [number, number]; phase: 'draw' | 'move' | 'wild' | 'defend' | 'over'; remaining: number;
  card: Card | null; deck: Card[]; deckLeft: number; discard: Card[]; deferred: Card | null;
  logs: string[]; lastMove: [number, number] | null; result: string | null; winner: number | null;
  captured: Piece[]; repetitions: Record<string, number>; notice: string;
};
export type Action = { type: 'draw' | 'end' | 'resign' | 'move' | 'wild'; from?: number; to?: number; promotion?: Kind };
export const opposite = (c: Color): Color => c === 'w' ? 'b' : 'w';
export const squareName = (i: number) => 'abcdefgh'[i % 8] + (8 - Math.floor(i / 8));
export const pieceNames: Record<Kind,string> = { p:'폰', n:'나이트', b:'비숍', r:'룩', q:'퀸', k:'킹' };
const inside = (r:number,c:number) => r >= 0 && r < 8 && c >= 0 && c < 8;
export function initialPosition():Position {
  const row: Kind[] = ['r','n','b','q','k','b','n','r'];
  return { board: Array.from({length:64},(_,i)=>i<8?{color:'b',kind:row[i]}:i<16?{color:'b',kind:'p'}:i>=56?{color:'w',kind:row[i-56]}:i>=48?{color:'w',kind:'p'}:null), rights:'KQkq', ep:null, halfmove:0 };
}
export function attacked(p:Position,at:number,by:Color):boolean {
  const ar=Math.floor(at/8), ac=at%8;
  for(let i=0;i<64;i++){
    const x=p.board[i]; if(!x || x.color!==by) continue;
    const r=Math.floor(i/8),c=i%8,dr=ar-r,dc=ac-c;
    if(x.kind==='p' && dr===(by==='w'?-1:1) && Math.abs(dc)===1) return true;
    if(x.kind==='n' && Math.abs(dr)*Math.abs(dc)===2) return true;
    if(x.kind==='k' && Math.max(Math.abs(dr),Math.abs(dc))===1) return true;
    const diagonal=Math.abs(dr)===Math.abs(dc)&&dr!==0;
    const straight=(dr===0)!==(dc===0);
    if((x.kind==='b'&&diagonal)||(x.kind==='r'&&straight)||(x.kind==='q'&&(diagonal||straight))){
      const sr=Math.sign(dr),sc=Math.sign(dc);let rr=r+sr,cc=c+sc,clear=true;
      while(rr!==ar||cc!==ac){if(p.board[rr*8+cc]){clear=false;break;}rr+=sr;cc+=sc;}
      if(clear)return true;
    }
  }
  return false;
}
export function inCheck(p:Position,color:Color):boolean {
  const king=p.board.findIndex(x=>x?.kind==='k'&&x.color===color);
  return king<0 || attacked(p,king,opposite(color));
}
function pseudo(p:Position,color:Color):Move[]{
  const out:Move[]=[];
  const add=(from:number,to:number,extra:Partial<Move>={})=>{
    const target=p.board[to];if(target?.color===color||target?.kind==='k')return;
    if(p.board[from]?.kind==='p'&&(to<8||to>=56)) for(const promotion of ['q','r','b','n'] as Kind[])out.push({from,to,...extra,promotion});
    else out.push({from,to,...extra});
  };
  for(let i=0;i<64;i++){
    const x=p.board[i];if(!x||x.color!==color)continue;
    const r=Math.floor(i/8),c=i%8;
    if(x.kind==='p'){
      const d=color==='w'?-1:1,nr=r+d;
      if(inside(nr,c)&&!p.board[nr*8+c]){
        add(i,nr*8+c);
        if(r===(color==='w'?6:1)&&!p.board[(r+d*2)*8+c])add(i,(r+d*2)*8+c);
      }
      for(const dc of [-1,1])if(inside(nr,c+dc)){
        const to=nr*8+c+dc,t=p.board[to];
        if(t&&t.color!==color)add(i,to);
        else if(to===p.ep&&!t&&p.board[r*8+c+dc]?.kind==='p'&&p.board[r*8+c+dc]?.color!==color)add(i,to,{ep:true});
      }
    }else if(x.kind==='n'){
      for(const [dr,dc] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]])if(inside(r+dr,c+dc))add(i,(r+dr)*8+c+dc);
    }else{
      const ds=x.kind==='b'?[[-1,-1],[-1,1],[1,-1],[1,1]]:x.kind==='r'?[[-1,0],[1,0],[0,-1],[0,1]]:[[-1,-1],[-1,1],[1,-1],[1,1],[-1,0],[1,0],[0,-1],[0,1]];
      for(const [dr,dc] of ds){let nr=r+dr,nc=c+dc;while(inside(nr,nc)){
        const at=nr*8+nc;add(i,at);if(p.board[at]||x.kind==='k')break;nr+=dr;nc+=dc;
      }}
      const home=color==='w'?60:4;
      if(x.kind==='k'&&i===home&&!inCheck(p,color)){
        for(const side of ['k','q'] as const){
          const right=color==='w'?side.toUpperCase():side,rook=side==='k'?home+3:home-4;
          const path=side==='k'?[home+1,home+2]:[home-1,home-2,home-3];
          const crossed=side==='k'?[home+1,home+2]:[home-1,home-2];
          if(p.rights.includes(right)&&p.board[rook]?.kind==='r'&&p.board[rook]?.color===color&&path.every(at=>!p.board[at])&&crossed.every(at=>!attacked(p,at,opposite(color))))add(i,side==='k'?home+2:home-2,{castle:side});
        }
      }
    }
  }
  return out;
}
export function applyMove(p:Position,m:Move):Position{
  const board=p.board.map(x=>x?{...x}:null),x=board[m.from]!;let rights=p.rights;
  const taken=board[m.to]||m.ep;
  board[m.from]=null;board[m.to]={...x,kind:m.promotion||x.kind};
  if(m.ep)board[m.to+(x.color==='w'?8:-8)]=null;
  if(m.castle){const rookFrom=m.castle==='k'?m.from+3:m.from-4,rookTo=m.castle==='k'?m.from+1:m.from-1;board[rookTo]=board[rookFrom];board[rookFrom]=null;}
  if(x.kind==='k')rights=rights.replace(x.color==='w'?/[KQ]/g:/[kq]/g,'');
  for(const [sq,right] of [[0,'q'],[7,'k'],[56,'Q'],[63,'K']] as [number,string][])if(m.from===sq||m.to===sq)rights=rights.replace(right,'');
  return {board,rights,ep:x.kind==='p'&&Math.abs(m.to-m.from)===16?(m.from+m.to)/2:null,halfmove:x.kind==='p'||taken?0:p.halfmove+1};
}
export const legalMoves=(p:Position,color:Color):Move[]=>pseudo(p,color).filter(m=>!inCheck(applyMove(p,m),color));
export const checkmate=(p:Position,color:Color)=>inCheck(p,color)&&legalMoves(p,color).length===0;
function randomBelow(n:number){const a=new Uint32Array(1),limit=4294967296-4294967296%n;do{crypto.getRandomValues(a);}while(a[0]>=limit);return a[0]%n;}
export function shuffle(cards:Card[]):Card[]{const copy=[...cards];for(let i=copy.length-1;i>0;i--){const j=randomBelow(i+1);[copy[i],copy[j]]=[copy[j],copy[i]];}return copy;}
export function createDeck():Card[]{
  const cards:Card[]=[];
  for(const color of ['red','yellow','green','blue']){
    cards.push({kind:'number',value:0,color});
    for(let value=1;value<=9;value++)for(let k=0;k<2;k++)cards.push({kind:'number',value,color});
    for(const kind of ['reverse','skip','plus2'] as const)for(let k=0;k<2;k++)cards.push({kind,value:kind==='plus2'?2:0,color});
  }
  for(let k=0;k<4;k++){cards.push({kind:'wild',value:0,color:'wild'});cards.push({kind:'plus4',value:4,color:'wild'});}
  return shuffle(cards);
}
export const isClassic=(g:Game)=>g.variant==='classic';
export function newGame(variant:Variant='cardmate'):Game{
  const classic=variant==='classic',deck=classic?[]:createDeck(),position=initialPosition();
  const key=JSON.stringify([position.board,position.rights,position.ep,['w','b'],0,[0,0]]);
  return {variant,position,colors:['w','b'],active:0,completed:[0,0],bonuses:[0,0],phase:classic?'move':'draw',remaining:classic?1:0,card:null,deck,deckLeft:deck.length,discard:[],deferred:null,logs:[classic?'기본 체스 시작 · 백이 먼저 움직입니다.':'게임 시작 · 플레이어 1이 먼저 카드를 뽑습니다.'],lastMove:null,result:null,winner:null,captured:[],repetitions:{[key]:1},notice:classic?'백의 차례입니다. 말을 선택해 한 번 움직이세요.':'중앙 더미에서 카드를 한 장 뽑으세요.'};
}
export function cardLabel(c:Card|null){if(!c)return '카드를 뽑으세요';return c.kind==='number'?`${c.value}`:({reverse:'진영 교환',skip:'건너뛰기',plus2:'+2',plus4:'+4',wild:'폰 변경'})[c.kind];}
export const protectedOpening=(g:Game)=>!isClassic(g)&&(g.completed[0]===0||g.completed[1]===0);
export function availableMoves(g:Game):Move[]{
  const c=g.colors[g.active];return legalMoves(g.position,c).filter(m=>!protectedOpening(g)||!checkmate(applyMove(g.position,m),opposite(c)));
}
export function availableWild(g:Game,from:number,kind:Kind):boolean{
  const c=g.colors[g.active];if(!['q','r','b','n'].includes(kind)||g.position.board[from]?.color!==c||g.position.board[from]?.kind!=='p')return false;
  const p={...g.position,board:g.position.board.map((x,i)=>i===from?{color:c,kind}:x)};
  return !inCheck(p,c)&&(!protectedOpening(g)||!checkmate(p,opposite(c)));
}
function log(g:Game,s:string){g.logs.push(s);if(g.logs.length>250)g.logs.shift();}
function endGame(g:Game,s:string,winner:number|null){g.phase='over';g.result=s;g.winner=winner;g.notice=s;log(g,s);}
function materialDraw(p:Position){
  const pieces=p.board.map((x,i)=>({x,i})).filter(({x})=>!!x&&x.kind!=='k');
  if(!pieces.length)return true;
  if(pieces.length===1&&['b','n'].includes(pieces[0].x!.kind))return true;
  if(pieces.every(({x})=>x!.kind==='b'))return new Set(pieces.map(({i})=>(Math.floor(i/8)+i%8)%2)).size===1;
  return false;
}
function finish(g:Game,skip=false){
  const actor=g.active;g.completed[actor]++;g.active=skip?actor:1-actor;g.phase=isClassic(g)?'move':'draw';g.remaining=isClassic(g)?1:0;g.deferred=null;
  const c=g.colors[g.active];
  if(checkmate(g.position,c)){endGame(g,`플레이어 ${2-g.active} 승리 · 체크메이트`,1-g.active);return;}
  if(!inCheck(g.position,c)&&legalMoves(g.position,c).length===0){endGame(g,'무승부 · 스테일메이트',null);return;}
  if(materialDraw(g.position)){endGame(g,'무승부 · 체크메이트할 기물 부족',null);return;}
  if(g.position.halfmove>=100){endGame(g,'무승부 · 폰 이동과 잡기 없이 100회 이동',null);return;}
  const key=JSON.stringify([g.position.board,g.position.rights,g.position.ep,g.colors,g.active,g.bonuses]);
  g.repetitions[key]=(g.repetitions[key]||0)+1;
  if(g.repetitions[key]>=3){endGame(g,'무승부 · 동일 국면 3회 반복',null);return;}
  g.notice=isClassic(g)?(inCheck(g.position,c)?'체크! 이번 수로 왕을 지키세요.':'말을 선택해 한 번 움직이세요.'):(inCheck(g.position,c)?'체크! 카드를 뽑고 첫 이동으로 왕을 지키세요.':'카드를 뽑아 다음 수를 시작하세요.');
}
function special(g:Game,c:Card){
  const actor=g.active;
  if(c.kind==='plus2'||c.kind==='plus4'){g.bonuses[actor]+=c.value;log(g,`플레이어 ${actor+1} · 다음 이동 보너스 +${c.value} (누적 ${g.bonuses[actor]})`);finish(g);}
  else if(c.kind==='reverse'){g.colors=[g.colors[1],g.colors[0]];log(g,'진영 교환 · 백과 흑의 조종권을 바꿨습니다.');finish(g);}
  else if(c.kind==='skip'){log(g,`플레이어 ${2-actor}의 차례를 건너뜁니다.`);finish(g,true);}
  else if(c.kind==='wild'){
    if(g.position.board.some((x,i)=>x?.color===g.colors[actor]&&x.kind==='p'&&(['q','r','b','n'] as Kind[]).some(kind=>availableWild(g,i,kind)))){g.phase='wild';g.notice='내 폰 하나를 선택하고 변경할 말을 고르세요.';}
    else{log(g,'변경할 폰이 없어 턴을 종료합니다.');finish(g);}
  }
}
export function transition(original:Game,action:Action):Game{
  if(original.phase==='over')throw new Error('이미 끝난 게임입니다.');
  if(isClassic(original)&&!['move','resign'].includes(action.type))throw new Error('기본 체스에서는 차례마다 말을 한 번 움직여야 합니다.');
  const g=structuredClone(original),color=g.colors[g.active];
  if(action.type==='resign'){endGame(g,`플레이어 ${2-g.active} 승리 · 상대 기권`,1-g.active);return g;}
  if(action.type==='draw'){
    if(g.phase!=='draw')throw new Error('현재 카드의 행동을 먼저 마쳐주세요.');
    if(!g.deck.length){g.deck=shuffle(g.discard);g.discard=[];log(g,'사용한 카드를 다시 섞었습니다.');}
    const card=g.deck.pop();if(!card)throw new Error('카드 더미가 비어 있습니다.');
    g.card=card;g.discard.push(card);g.deckLeft=g.deck.length;log(g,`플레이어 ${g.active+1} · ${cardLabel(card)} 카드`);
    if(card.kind==='number'){
      const bonus=g.bonuses[g.active];g.bonuses[g.active]=0;g.remaining=card.value+bonus;
      if(inCheck(g.position,color))g.remaining=Math.max(1,g.remaining);
      g.phase='move';g.notice=`최대 ${g.remaining}회 이동할 수 있습니다.`;
      if(g.remaining===0)finish(g);
    }else if(inCheck(g.position,color)){g.phase='defend';g.remaining=1;g.deferred=card;g.notice='먼저 체크를 해소하세요. 그다음 카드 효과를 적용합니다.';}
    else special(g,card);
  }else if(action.type==='end'){
    if(g.phase!=='move')throw new Error('지금은 턴을 종료할 수 없습니다.');
    if(inCheck(g.position,color))throw new Error('먼저 체크를 해소해야 합니다.');
    log(g,`플레이어 ${g.active+1} · 턴 종료`);finish(g);
  }else if(action.type==='move'){
    if(!['move','defend'].includes(g.phase))throw new Error('먼저 카드를 뽑으세요.');
    const candidates=availableMoves(g).filter(m=>m.from===action.from&&m.to===action.to);
    const m=candidates.find(m=>(m.promotion||null)===(action.promotion||null));
    if(!m)throw new Error(protectedOpening(g)?'불가능한 이동입니다. 첫 턴에는 체크메이트할 수 없습니다.':'체스 규칙상 불가능한 이동입니다.');
    const piece=g.position.board[m.from]!,taken=g.position.board[m.to]||(m.ep?g.position.board[m.to+(color==='w'?8:-8)]:null);
    if(taken)g.captured.push(taken);
    g.position=applyMove(g.position,m);g.lastMove=[m.from,m.to];g.remaining--;
    log(g,`${pieceNames[piece.kind]} ${squareName(m.from)} → ${squareName(m.to)}${taken?' · 잡기':''}${m.promotion?' · '+pieceNames[m.promotion]+' 승격':''}`);
    if(checkmate(g.position,opposite(color))){endGame(g,`플레이어 ${g.active+1} 승리 · 체크메이트`,g.active);return g;}
    if(inCheck(g.position,opposite(color))){log(g,isClassic(g)?'체크':'체크 · 남은 이동을 종료합니다.');finish(g);}
    else if(g.phase==='defend'){const pending=g.deferred!;g.deferred=null;special(g,pending);}
    else if(g.remaining<=0)finish(g);
    else g.notice=`${g.remaining}회 더 이동하거나 턴을 끝낼 수 있습니다.`;
  }else if(action.type==='wild'){
    if(g.phase!=='wild'||action.from===undefined||!action.promotion||!availableWild(g,action.from,action.promotion))throw new Error('변경할 수 없는 폰 또는 말입니다.');
    g.position.board[action.from]={color,kind:action.promotion};g.position.halfmove=0;g.position.ep=null;
    log(g,`와일드 · ${squareName(action.from)} 폰을 ${pieceNames[action.promotion]}으로 변경`);
    if(checkmate(g.position,opposite(color)))endGame(g,`플레이어 ${g.active+1} 승리 · 체크메이트`,g.active);else finish(g);
  }else throw new Error('알 수 없는 행동입니다.');
  return g;
}
