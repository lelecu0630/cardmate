import { env } from 'cloudflare:workers';
export function database():D1Database {
  const db=(env as unknown as {DB?:D1Database}).DB;
  if(!db)throw new Error('온라인 대전을 연결할 수 없습니다. 잠시 후 다시 시도하거나 한 화면 대전을 이용하세요.');
  return db;
}
